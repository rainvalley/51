#ifndef __WAVE_H_
#define __WAVE_H_
#include "stc15f2k60s2.h"
void init_timer1(void);
unsigned char get_dis();
#endif