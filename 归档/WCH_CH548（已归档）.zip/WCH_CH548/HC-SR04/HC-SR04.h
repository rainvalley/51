#ifndef __HC_SR04_H__
#define __HC_SR04_H__
#include ".\Public\CH549.H"
#include ".\Public\DEBUG.H"


extern UINT16 distance_time ;
extern UINT16 distance  ;
void SCAN_DIS(); //��������ຯ��



#endif
